// SPDX-License-Identifier: AGPL-3.0-only
//! GGUF `attn_k_b` / `attn_v_b` → host `k_b_proj` / `v_b_proj` with TP head slice.

use std::collections::HashMap;
use std::sync::Mutex;

use anyhow::{Context, Result, bail, ensure};

use super::dequant_cpu::GgmlType;
use super::GgufLoader;
use crate::gpu::GpuBackend;
use crate::weights::{WeightDtype, WeightTensor};

struct MlaHalf {
    raw: Vec<u8>,
    shape: Vec<usize>,
    id: u32,
}

static MLA_KV: Mutex<Option<HashMap<String, (Option<MlaHalf>, Option<MlaHalf>)>>> =
    Mutex::new(None);

pub(super) fn stash_mla_kv(
    loader: &GgufLoader,
    gpu: &dyn GpuBackend,
    hf_name: &str,
    raw: &[u8],
    hf_shape: &[usize],
    id: u32,
    weights: &mut HashMap<String, WeightTensor>,
) -> Result<()> {
    let (stem, is_k) = if let Some(stem) = hf_name.strip_suffix(".self_attn.kv_b_proj.weight") {
        (stem.to_string(), true)
    } else if let Some(stem) = hf_name.strip_suffix(".self_attn.v_b_proj.weight") {
        (stem.to_string(), false)
    } else if let Some(stem) = hf_name.strip_suffix(".self_attn.k_b_proj.weight") {
        (stem.to_string(), true)
    } else {
        bail!("{hf_name}: not an MLA k_b/v_b tensor");
    };
    let half = MlaHalf {
        raw: raw.to_vec(),
        shape: hf_shape.to_vec(),
        id,
    };
    let ready = {
        let mut guard = MLA_KV.lock().expect("mla kv lock");
        let map = guard.get_or_insert_with(HashMap::new);
        let slot = map.entry(stem.clone()).or_insert((None, None));
        if is_k {
            slot.0 = Some(half);
        } else {
            slot.1 = Some(half);
        }
        if slot.0.is_some() && slot.1.is_some() {
            map.remove(&stem)
        } else {
            None
        }
    };
    if let Some((k, v)) = ready {
        upload_split(loader, gpu, &stem, k.unwrap(), v.unwrap(), weights)?;
    }
    Ok(())
}

fn dequant_f32(id: u32, raw: &[u8], elems: usize) -> Result<Vec<f32>> {
    let mut vals = vec![0f32; elems];
    let gt = GgmlType::from_id(id, 32).context("mla kv ggml type")?;
    super::dequant_cpu::dequant_to_f32(gt, raw, elems, &mut vals).context("mla kv dequant")?;
    Ok(vals)
}

fn upload_bf16(
    gpu: &dyn GpuBackend,
    name: String,
    f32s: &[f32],
    shape: Vec<usize>,
    weights: &mut HashMap<String, WeightTensor>,
) -> Result<()> {
    let mut bytes = Vec::with_capacity(f32s.len() * 2);
    for &x in f32s {
        bytes.extend_from_slice(&half::bf16::from_f32(x).to_le_bytes());
    }
    let ptr = gpu.alloc(bytes.len())?;
    gpu.copy_h2d(&bytes, ptr)?;
    weights.insert(
        name,
        WeightTensor {
            ptr,
            shape,
            dtype: WeightDtype::BF16,
        },
    );
    Ok(())
}

/// HF shapes: k `[H, kv_lora, nope]`, v `[H, v_dim, kv_lora]`.
/// Host index: k[h*lora*nope + l*nope + d], v[h*v*lora + d*lora + l].
fn upload_split(
    loader: &GgufLoader,
    gpu: &dyn GpuBackend,
    stem: &str,
    k: MlaHalf,
    v: MlaHalf,
    weights: &mut HashMap<String, WeightTensor>,
) -> Result<()> {
    ensure!(k.shape.len() == 3, "{stem} k_b shape {:?}", k.shape);
    ensure!(v.shape.len() == 3, "{stem} v_b shape {:?}", v.shape);
    let heads = k.shape[0];
    let kv_lora = k.shape[1];
    let nope = k.shape[2];
    let v_dim = v.shape[1];
    ensure!(
        v.shape[0] == heads && v.shape[2] == kv_lora,
        "{stem} v_b {:?} vs k {:?}",
        v.shape,
        k.shape
    );
    let tp = loader.tp_world_size.max(1);
    ensure!(heads % tp == 0, "{stem} heads {heads} not divisible by TP{tp}");
    let local_h = heads / tp;
    let h0 = loader.tp_rank * local_h;
    let kd = dequant_f32(k.id, &k.raw, heads * kv_lora * nope)?;
    let vd = dequant_f32(v.id, &v.raw, heads * v_dim * kv_lora)?;

    let mut k_local = vec![0f32; local_h * kv_lora * nope];
    let mut v_local = vec![0f32; local_h * v_dim * kv_lora];
    for i in 0..local_h {
        let h = h0 + i;
        for l in 0..kv_lora {
            for d in 0..nope {
                k_local[i * kv_lora * nope + l * nope + d] =
                    kd[h * kv_lora * nope + l * nope + d];
            }
        }
        for d in 0..v_dim {
            for l in 0..kv_lora {
                v_local[i * v_dim * kv_lora + d * kv_lora + l] =
                    vd[h * v_dim * kv_lora + d * kv_lora + l];
            }
        }
    }
    upload_bf16(
        gpu,
        format!("{stem}.self_attn.k_b_proj.weight"),
        &k_local,
        vec![local_h, kv_lora, nope],
        weights,
    )?;
    upload_bf16(
        gpu,
        format!("{stem}.self_attn.v_b_proj.weight"),
        &v_local,
        vec![local_h, v_dim, kv_lora],
        weights,
    )?;
    Ok(())
}

pub(super) fn flush_mla_kv_b() -> Result<()> {
    let mut guard = MLA_KV.lock().expect("mla kv lock");
    if let Some(map) = guard.as_ref() {
        if !map.is_empty() {
            let left: Vec<_> = map.keys().cloned().collect();
            bail!("K3 MLA kv_b/v_b pair missing for {left:?}");
        }
    }
    *guard = None;
    Ok(())
}
